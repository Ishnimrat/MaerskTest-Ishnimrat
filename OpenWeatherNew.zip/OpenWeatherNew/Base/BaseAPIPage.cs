﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using RestSharp;

namespace OpenWeatherNew.Base
{
    public class BaseAPIPage
    {
        //public static readonly Logger Logger = LogManager.GetCurrentClassLogger();

        public BaseAPIPage(RestClient client)
        {
            this.client = client;
        }

        protected RestClient client { get; set; }
    }
}
