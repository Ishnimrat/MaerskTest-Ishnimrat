﻿using NUnit.Framework;
using OpenWeatherNew.Properties;
using RestSharp;
using System.Net;

namespace OpenWeatherNew.Base
{
    public class BaseAPITest
    {
        private static string baseUrl = TestSettings.Default.baseUrl;

        public RestClient client { get; set; }

        [OneTimeSetUp]
        public void BeforeEachTestClass()
        {
            client = this.Start(baseUrl);
        }

        public RestClient Start(string baseUrl)
        {
            this.client = new RestClient(baseUrl);
            ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls12 | SecurityProtocolType.Tls11 | SecurityProtocolType.Tls;
            ServicePointManager.ServerCertificateValidationCallback += (sender, certificate, chain, sslPolicyErrors) => true;
            return client;
        }
    }
}
