﻿using NUnit.Framework;
using OpenWeatherNew.Base;
using OpenWeatherNew.PageObjects;
using RestSharp;
using Newtonsoft.Json.Linq;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OpenWeatherNew.TestSuite
{
    [TestFixture]
    public class GetCityWeatherAPI : BaseAPITest
    {
        public GetCityWeather CityWeatherAPI => new GetCityWeather(this.client);

        [TestCase("London")]
        public void TestResposneStatusAndCode(string city)
        {
            IRestResponse response = this.CityWeatherAPI.GetWeatherResponse(this.client, city, "45c18878305c5b3bc3b6d331e9c0e16a");
            Assert.That(response.StatusCode.ToString() == "OK", "The response generated is not OK");            
            JObject jresponse = JObject.Parse(response.Content.ToString());   
            Assert.That("200" == jresponse["cod"].ToString(), "Mismatch in actual and expected city names");
        }

        [TestCase("Berlin")]
        public void TestResponseValidations(string city)
        {
            IRestResponse response = this.CityWeatherAPI.GetWeatherResponse(this.client, city, "45c18878305c5b3bc3b6d331e9c0e16a");
            Assert.That(response.StatusCode.ToString() == "OK", "The response generated is not OK");
            JObject jresponse = JObject.Parse(response.Content.ToString());
            Assert.That(city == jresponse["name"].ToString(), "Mismatch in actual and expected city names");
            Assert.That("13.41" == jresponse["coord"]["lon"].ToString(), "Mismatch in actual and expected longitude values");
            Assert.That("52.52" == jresponse["coord"]["lat"].ToString(), "Mismatch in actual and expected latitude values");
        }
    }
}
