﻿using OpenWeatherNew.Base;
using OpenWeatherNew.Properties;
using RestSharp;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OpenWeatherNew.PageObjects
{
    public class GetCityWeather : BaseAPIPage
    {
        public RestClient client;
        public GetCityWeather(RestClient client)
           : base(client)
        {
            this.client = client;
        }

        public IRestResponse GetWeatherResponse(RestClient client, string city, string apikey)
        {
            var request = new RestRequest("/data/2.5/weather", Method.GET);
            request.AddQueryParameter("q", city);
            request.AddQueryParameter("appid", TestSettings.Default.apiKey);
            request.AddHeader("content-type", "application/json");
            IRestResponse restresponse = client.Execute(request);            
            return restresponse;
        }
    }
}
